﻿    /*
    ** Watch_Face_Editor tool v 17.1
    ** watchface js version v2.1.1
    ** Copyright © SashaCX75. All Rights Reserved
    */
   
    try {
    (() => {
        //start of ignored block
        const __$$app$$__ = __$$hmAppManager$$__.currentApp;
        function getApp() {
            return __$$app$$__.app;
        }
        function getCurrentPage() {
            return __$$app$$__.current && __$$app$$__.current.module;
        }
        const __$$module$$__ = __$$app$$__.current;
        const h = new DeviceRuntimeCore.WidgetFactory(new DeviceRuntimeCore.HmDomApi(__$$app$$__, __$$module$$__));
        const {px} = __$$app$$__.__globals__;
        //const logger = Logger.getLogger('watchface_SashaCX75');
        const logger = DeviceRuntimeCore.HmLogger.getLogger('watchface_SashaCX75')
        //end of ignored block

        //dynamic modify start

        
        let normal_background_bg_img = ''
        let normal_battery_image_progress_img_level = ''
        let normal_step_circle_scale = ''
        let normal_date_img_date_month_img = ''
        let normal_day_text_font = ''
        let normal_analog_clock_time_pointer_hour = ''
        let normal_analog_clock_time_pointer_minute = ''
        let idle_background_bg_img = ''
        let idle_battery_current_text_font = ''
        let idle_date_img_date_month_img = ''
        let idle_day_text_font = ''
        let idle_analog_clock_time_pointer_hour = ''
        let idle_analog_clock_time_pointer_minute = ''
        let timeSensor = '';


        //dynamic modify end

        __$$module$$__.module = DeviceRuntimeCore.WatchFace({
            init_view() {
                //dynamic modify start
                    
                
            // FontName: Inter-VariableFont_opsz,wght.ttf; FontSize: 22
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 318,
              h: 37,
              text_size: 22,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Inter-VariableFont_opsz,wght.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.CENTER_H,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // FontName: Inter-VariableFont_opsz,wght.ttf; FontSize: 25
            hmUI.createWidget(hmUI.widget.TEXT, {
              x: 388,
              y: 448,
              w: 357,
              h: 43,
              text_size: 25,
              char_space: 0,
              line_space: 0,
              font: 'fonts/Inter-VariableFont_opsz,wght.ttf',
              color: 0xFFFFFFFF,
              align_h: hmUI.align.LEFT,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              text: "0123456789 _-.,:;`'%°\\/",
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            console.log('Watch_Face.ScreenNormal');
            normal_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'bg.png',
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            normal_battery_image_progress_img_level = hmUI.createWidget(hmUI.widget.IMG_LEVEL, {
              x: 194,
              y: 420,
              image_array: ["battery_state_00.png","battery_state_01.png","battery_state_02.png","battery_state_03.png","battery_state_04.png","battery_state_05.png","battery_state_06.png","battery_state_07.png","battery_state_08.png","battery_state_09.png"],
              image_length: 10,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_step_circle_scale = hmUI.createWidget(hmUI.widget.Circle_Scale, {
              // center_x: 195,
              // center_y: 225,
              // start_angle: 0,
              // end_angle: 360,
              // radius: 177,
              // line_width: 2,
              // line_cap: Flat,
              // color: 0xFF0F2B61,
              // mirror: False,
              // inversion: False,
              // alpha: 255,
              // type: hmUI.data_type.STEP,
              // show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            let screenType = hmSetting.getScreenType();
            normal_step_circle_scale = hmUI.createWidget(hmUI.widget.ARC_PROGRESS, {
              center_x: 195,
              center_y: 225,
              start_angle: 0,
              end_angle: 360,
              radius: 176,
              line_width: 2,
              corner_flag: 3,
              color: 0xFF0F2B61,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });
            
            const step = hmSensor.createSensor(hmSensor.id.STEP);
            step.addEventListener(hmSensor.event.CHANGE, function() {
              scale_call();
            });

            normal_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 192,
              month_startY: 272,
              month_sc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_tc_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_en_array: ["month_01.png","month_02.png","month_03.png","month_04.png","month_05.png","month_06.png","month_07.png","month_08.png","month_09.png","month_10.png","month_11.png","month_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            if (!timeSensor) timeSensor = hmSensor.createSensor(hmSensor.id.TIME);
            timeSensor.addEventListener(timeSensor.event.DAYCHANGE, function() {
              time_update(true);
            });
            timeSensor.addEventListener(timeSensor.event.MINUTEEND, function() {
              time_update(false, true);
            });

            const CLOCK_CENTER_X = 195;
            const CLOCK_CENTER_Y = 225;
            const HOUR_PIVOT_X = 4;
            const HOUR_PIVOT_Y = 118;
            const MINUTE_PIVOT_X = 3;
            const MINUTE_PIVOT_Y = 158;

            function getHandImgParams(pivotX, pivotY) {
              return {
                x: 0,
                y: 0,
                w: 390,
                h: 450,
                pos_x: CLOCK_CENTER_X - pivotX,
                pos_y: CLOCK_CENTER_Y - pivotY,
                center_x: CLOCK_CENTER_X,
                center_y: CLOCK_CENTER_Y,
              };
            }

            const hourHandImgParams = getHandImgParams(HOUR_PIVOT_X, HOUR_PIVOT_Y);
            const minuteHandImgParams = getHandImgParams(MINUTE_PIVOT_X, MINUTE_PIVOT_Y);

            function getCounterClockwiseAngles(hour, minute) {
              const hour12 = hour % 12;
              const minuteAngle = (360 - minute * 6) % 360;
              const hourAngle = (360 - (hour12 * 30 + minute * 0.5)) % 360;
              return { hourAngle, minuteAngle };
            }

            function updateClockHands() {
              const { hourAngle, minuteAngle } = getCounterClockwiseAngles(timeSensor.hour, timeSensor.minute);

              normal_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, Object.assign({}, hourHandImgParams, { angle: hourAngle }));
              normal_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, Object.assign({}, minuteHandImgParams, { angle: minuteAngle }));
              idle_analog_clock_time_pointer_hour.setProperty(hmUI.prop.MORE, Object.assign({}, hourHandImgParams, { angle: hourAngle }));
              idle_analog_clock_time_pointer_minute.setProperty(hmUI.prop.MORE, Object.assign({}, minuteHandImgParams, { angle: minuteAngle }));
            }

            function time_update(updateHour = false, updateMinute = false) {
              console.log('time_update()');

              console.log('day font');
              if (updateHour) {
                let normal_dayStr = timeSensor.day.toString();
                normal_dayStr = normal_dayStr.padStart(2, '0');
                normal_day_text_font.setProperty(hmUI.prop.TEXT, normal_dayStr );
              };

              console.log('day font');
              if (updateHour) {
                let idle_dayStr = timeSensor.day.toString();
                idle_dayStr = idle_dayStr.padStart(2, '0');
                idle_day_text_font.setProperty(hmUI.prop.TEXT, idle_dayStr );
              };

              if (updateMinute) {
                updateClockHands();
              }
            };

            normal_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 136,
              y: 268,
              w: 42,
              h: 32,
              text_size: 22,
              char_space: 0,
              font: 'fonts/Inter-VariableFont_opsz,wght.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_NORMAL,
            });

            // normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            //   hour_path: 'arrow_hour.png',
            //   hour_centerX: 195,
            //   hour_centerY: 225,
            //   hour_posX: 4,
            //   hour_posY: 118,
            //   show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            // normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            //   minute_path: 'arrow_minutes.png',
            //   minute_centerX: 195,
            //   minute_centerY: 225,
            //   minute_posX: 3,
            //   minute_posY: 158,
            //   show_level: hmUI.show_level.ONLY_NORMAL,
            // });

            normal_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.IMG, Object.assign({}, hourHandImgParams, {
              src: 'arrow_hour.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            }));

            normal_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.IMG, Object.assign({}, minuteHandImgParams, {
              src: 'arrow_minutes.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_NORMAL,
            }));


            console.log('Watch_Face.ScreenAOD');
            idle_background_bg_img = hmUI.createWidget(hmUI.widget.IMG, {
              x: 0,
              y: 0,
              w: 390,
              h: 450,
              src: 'bg_AOD.png',
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_battery_current_text_font = hmUI.createWidget(hmUI.widget.TEXT_FONT, {
              x: 120,
              y: 410,
              w: 150,
              h: 40,
              text_size: 25,
              char_space: 0,
              font: 'fonts/Inter-VariableFont_opsz,wght.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              unit_type: 1,
              type: hmUI.data_type.BATTERY,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_date_img_date_month_img = hmUI.createWidget(hmUI.widget.IMG_DATE, {
              month_startX: 192,
              month_startY: 272,
              month_sc_array: ["month_AOD_01.png","month_AOD_02.png","month_AOD_03.png","month_AOD_04.png","month_AOD_05.png","month_AOD_06.png","month_AOD_07.png","month_AOD_08.png","month_AOD_09.png","month_AOD_10.png","month_AOD_11.png","month_AOD_12.png"],
              month_tc_array: ["month_AOD_01.png","month_AOD_02.png","month_AOD_03.png","month_AOD_04.png","month_AOD_05.png","month_AOD_06.png","month_AOD_07.png","month_AOD_08.png","month_AOD_09.png","month_AOD_10.png","month_AOD_11.png","month_AOD_12.png"],
              month_en_array: ["month_AOD_01.png","month_AOD_02.png","month_AOD_03.png","month_AOD_04.png","month_AOD_05.png","month_AOD_06.png","month_AOD_07.png","month_AOD_08.png","month_AOD_09.png","month_AOD_10.png","month_AOD_11.png","month_AOD_12.png"],
              month_is_character: true ,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            idle_day_text_font = hmUI.createWidget(hmUI.widget.TEXT, {
              x: 136,
              y: 268,
              w: 42,
              h: 32,
              text_size: 22,
              char_space: 0,
              font: 'fonts/Inter-VariableFont_opsz,wght.ttf',
              color: 0xFFFFFFFF,
              line_space: 0,
              align_v: hmUI.align.CENTER_V,
              text_style: hmUI.text_style.ELLIPSIS,
              align_h: hmUI.align.CENTER_H,
              // padding: true,
              show_level: hmUI.show_level.ONLY_AOD,
            });

            // idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            //   hour_path: 'arrow_AOD_hour.png',
            //   hour_centerX: 195,
            //   hour_centerY: 225,
            //   hour_posX: 4,
            //   hour_posY: 118,
            //   show_level: hmUI.show_level.ONLY_AOD,
            // });

            // idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.TIME_POINTER, {
            //   minute_path: 'arrow_AOD_minutes.png',
            //   minute_centerX: 195,
            //   minute_centerY: 225,
            //   minute_posX: 3,
            //   minute_posY: 158,
            //   show_level: hmUI.show_level.ONLY_AOD,
            // });

            idle_analog_clock_time_pointer_hour = hmUI.createWidget(hmUI.widget.IMG, Object.assign({}, hourHandImgParams, {
              src: 'arrow_AOD_hour.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            }));

            idle_analog_clock_time_pointer_minute = hmUI.createWidget(hmUI.widget.IMG, Object.assign({}, minuteHandImgParams, {
              src: 'arrow_AOD_minutes.png',
              angle: 0,
              show_level: hmUI.show_level.ONLY_AOD,
            }));

            updateClockHands();

            function scale_call() {
              console.log('scale_call()');

                console.log('update scales STEP');
                
                let valueStep = step.current;
                let targetStep = step.target;
                let progressStep = valueStep/targetStep;
                if (progressStep > 1) progressStep = 1;
                let progress_cs_normal_step = progressStep;

                if (screenType != hmSetting.screen_type.AOD) {

                  // normal_step_circle_scale_circle_scale
                  let level = Math.round(progress_cs_normal_step * 100);
                  if (normal_step_circle_scale) {
                    normal_step_circle_scale.setProperty(hmUI.prop.MORE, {                      
                      center_x: 195,
                      center_y: 225,
                      start_angle: 0,
                      end_angle: 360,
                      radius: 176,
                      line_width: 2,
                      corner_flag: 3,
                      color: 0xFF0F2B61,
                      show_level: hmUI.show_level.ONLY_NORMAL,
                      level: level,
                    });
                  };
                };

            };

            const widgetDelegate = hmUI.createWidget(hmUI.widget.WIDGET_DELEGATE, {
              resume_call: (function () {
                console.log('resume_call()');
                scale_call();
                time_update(true, true);
              }),
            });

                //dynamic modify end
            },
            onInit() {
                logger.log('index page.js on init invoke');
            },
            build() {
                this.init_view();
                logger.log('index page.js on ready invoke');
            },
            onDestroy() {
                logger.log('index page.js on destroy invoke');
            }
        });
        ;
    })();
} catch (e) {
    console.log('Mini Program Error', e);
    e && e.stack && e.stack.split(/\n/).forEach(i => console.log('error stack', i));
    ;
}